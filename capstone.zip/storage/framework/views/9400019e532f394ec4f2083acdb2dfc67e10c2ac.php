<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\capstone\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>