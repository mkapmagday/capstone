<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table>
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider">USER_ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider">LAST NAME </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider">FIRST NAME</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider">DOCUMENT NAME</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider">STATUS</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-black-500 dark:text-black-200 uppercase tracking-wider" style="text-align:center ;">ACTIONS
                        </tr>
                        <?php $__currentLoopData = $docres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($docress->user_id); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($docress->lname); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($docress->fname); ?></td>
                            <?php $__currentLoopData = $doclist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($docress->document_id == $document->id): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($document->document_name); ?></td>
                            <?php if($docress->status == "pending"): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><button type="button" class="btn btn-primary" disabled><?php echo e($docress->status); ?></button></td>
                            <?php elseif($docress->status == "approved"): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><button type="button" class="btn btn-secondary" disabled><?php echo e($docress->status); ?></button></td>
                            <?php elseif($docress->status == "for_claiming"): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><button type="button" class="btn btn-success" disabled><?php echo e($docress->status); ?></button></td>
                            <?php elseif($docress->status == "claimed"): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><button type="button" class="btn btn-danger" disabled><?php echo e($docress->status); ?></button></td>
                            <?php endif; ?>                            <td class="px-6 py-4 whitespace-nowrap">
                                <form action="<?php echo e(route('residentpdf.show',$docress->id)); ?>">
                                    <button type="submit" class="btn btn-success">Show</button>
                                </form>
                            </td>
                            <?php endif; ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($docres->links()); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<?php /**PATH C:\xampp\htdocs\capstone\resources\views/resident/docres/docresstatus.blade.php ENDPATH**/ ?>